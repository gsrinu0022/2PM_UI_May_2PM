x=10
print(x)
name="sreenivas"
print(name)